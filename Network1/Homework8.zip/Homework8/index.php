<!DOCTYPE HTLM>
<html>
<head>
<meta charset="utf-8">
<title>Test1</title>
</head>

<body>
<?php
print 'Hello World! This is Stan calling :)<br>';
phpinfo();
?>
</body>
</html>